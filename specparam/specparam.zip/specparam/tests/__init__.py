"""Tests for the spectral parameterization module."""
