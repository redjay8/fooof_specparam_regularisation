"""Sub-module for computing measures of interest on data & model parameters."""
