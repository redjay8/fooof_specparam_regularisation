"""Bands sub-module."""

from .bands import Bands
