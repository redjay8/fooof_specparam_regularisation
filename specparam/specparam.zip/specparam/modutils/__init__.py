"""Module related utilities - generally for internal use."""
